package com.example.demo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface Interface_Student extends CrudRepository<Student,Integer> {

	List <Student> findBySemester(int semester);

	List<Student> findByTeachersName(String teachersName);
	
	@Query( "select Student.id,Teacher.nameTeacher from Student Student,Teacher Teacher  where Student.teachersName='Pavlos' and Teacher.id=1")
	List<Object> findByNameOfTeacher(String teachersName);

	
}
