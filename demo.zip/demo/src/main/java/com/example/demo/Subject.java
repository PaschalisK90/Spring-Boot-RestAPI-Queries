package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Subject")
public class Subject {
    @Id
    @Column(name="id")
    int id;
    
    @Column(name="nameOfSubject")
	String nameOfSubject;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNameOfSubject() {
		return nameOfSubject;
	}

	public void setNameOfSubject(String nameOfSubject) {
		this.nameOfSubject = nameOfSubject;
	}

	@Override
	public String toString() {
		return "Subject [id=" + id + ", nameOfSubject=" + nameOfSubject + "]";
	}
    
//    @OneToOne(fetch = FetchType.LAZY,mappedBy="Subject")
//	Student Student;
//    @OneToOne(fetch = FetchType.LAZY,mappedBy="Subject")
//	Semester Semester;
//    @OneToOne(fetch = FetchType.LAZY,mappedBy="Subject")
//    Teacher Teacher;
	

	
}
