package com.example.demo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface Interface_Semester extends JpaRepository<Semester,Integer> {
	@Query( "from Semester Semester LEFT JOIN Subject Subject ON Semester.nameOfSubject=Subject.nameOfSubject")
	List<Semester>  findAllByTeacher();
}
