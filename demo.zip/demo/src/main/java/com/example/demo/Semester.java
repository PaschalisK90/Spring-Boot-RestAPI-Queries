package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Semester")
public class Semester {
	@Id
	@Column(name="semester",unique = true)
    int semester;
//	@OneToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name="nameOfSubjects")
//    Subject Subject;
//    @OneToOne(fetch = FetchType.LAZY,mappedBy="Semester")
//    Student Student;
	
	
	@Column(name="nameOfSubject")
	String nameOfSubject;


	public int getSemester() {
		return semester;
	}


	public void setSemester(int semester) {
		this.semester = semester;
	}


	public String getNameOfSubject() {
		return nameOfSubject;
	}


	public void setNameOfSubject(String nameOfSubject) {
		this.nameOfSubject = nameOfSubject;
	}


	@Override
	public String toString() {
		return "Semester [semester=" + semester + ", nameOfSubject=" + nameOfSubject + "]";
	}
	
	
    
	
    
}