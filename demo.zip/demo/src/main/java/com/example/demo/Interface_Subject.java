package com.example.demo;

import org.springframework.data.repository.CrudRepository;

public interface Interface_Subject extends CrudRepository<Subject,Integer> {
//	List<Subject>findByNameOfSubject(String nameOfSubject);

}
