package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Teacher")
public class Teacher {

	@Id
	@Column(name="id")
	int id;
	@Column(name="nameTeacher")
	String nameTeacher;
	@Column(name="surnameTeacher")
	String surnameTeacher;
	@Column(name="age")
	int age;
	@Column(name="weight")
	double weight;
	@Column(name="height")
	double height;
	@Column(name="fathers_name")
	String fathers_name;
	@Column(name="mothers_name")
	String mothers_name;
	@Column(name="title")
	String title;
//	@OneToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name="id")
//	Subject Subject;
	@Column(name="wage")
	double wage;
//	@OneToOne(fetch = FetchType.LAZY,mappedBy="Teacher")
//	Student Student;
	
	
	@Column(name="teachingSubject")
	String teachingSubject;


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNameTeacher() {
		return nameTeacher;
	}


	public void setNameTeacher(String nameTeacher) {
		this.nameTeacher = nameTeacher;
	}


	public String getSurnameTeacher() {
		return surnameTeacher;
	}


	public void setSurnameTeacher(String surnameTeacher) {
		this.surnameTeacher = surnameTeacher;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public double getWeight() {
		return weight;
	}


	public void setWeight(double weight) {
		this.weight = weight;
	}


	public double getHeight() {
		return height;
	}


	public void setHeight(double height) {
		this.height = height;
	}


	public String getFathers_name() {
		return fathers_name;
	}


	public void setFathers_name(String fathers_name) {
		this.fathers_name = fathers_name;
	}


	public String getMothers_name() {
		return mothers_name;
	}


	public void setMothers_name(String mothers_name) {
		this.mothers_name = mothers_name;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public double getWage() {
		return wage;
	}


	public void setWage(double wage) {
		this.wage = wage;
	}


	public String getTeachingSubject() {
		return teachingSubject;
	}


	public void setTeachingSubject(String teachingSubject) {
		this.teachingSubject = teachingSubject;
	}


	@Override
	public String toString() {
		return "Teacher [id=" + id + ", nameTeacher=" + nameTeacher + ", surnameTeacher=" + surnameTeacher + ", age="
				+ age + ", weight=" + weight + ", height=" + height + ", fathers_name=" + fathers_name
				+ ", mothers_name=" + mothers_name + ", title=" + title + ", wage=" + wage + ", teachingSubject="
				+ teachingSubject + "]";
	}
	
	
	
	
	
}
