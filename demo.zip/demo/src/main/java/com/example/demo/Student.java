package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Table;





//@Component
//@Scope(value="prototype")
@Entity
@Table(name="Student")
public class Student {
	@Id
   @Column(name="id")
   int id;
   
   @Column(name="semester")
   int semester;
   
   @Column(name="teachersName")
   String teachersName;
   
   @Column(name="nameStudent",unique = true)
    String nameStudent;
   @Column(name="surname")
   String surname;
   @Column(name="age")
   int age;
   @Column(name="weight")
   double weight;
   @Column(name="height")
   double height;
   @Column(name="fathers_name")
   String fathers_name;
   @Column(name="mothers_name")
   String mothers_name;
   
//	@OneToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name="id")
//   Subject Subject; 
//	@OneToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name="id")
//	Teacher Teacher;
   @Column(name="grade")
   double grade;
   @Column(name="sumgrade")
   double sumgrade;
//   @OneToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name="semester")
//  	Semester Semester;
   @Column(name="average")
   double average;//=sumgrade/Semester.semester;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getSemester() {
	return semester;
}
public void setSemester(int semester) {
	this.semester = semester;
}
public String getTeachers_name() {
	return teachersName;
}
public void setTeachers_name(String teachers_name) {
	this.teachersName = teachers_name;
}
public String getNameStudent() {
	return nameStudent;
}
public void setNameStudent(String nameStudent) {
	this.nameStudent = nameStudent;
}
public String getSurname() {
	return surname;
}
public void setSurname(String surname) {
	this.surname = surname;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public double getWeight() {
	return weight;
}
public void setWeight(double weight) {
	this.weight = weight;
}
public double getHeight() {
	return height;
}
public void setHeight(double height) {
	this.height = height;
}
public String getFathers_name() {
	return fathers_name;
}
public void setFathers_name(String fathers_name) {
	this.fathers_name = fathers_name;
}
public String getMothers_name() {
	return mothers_name;
}
public void setMothers_name(String mothers_name) {
	this.mothers_name = mothers_name;
}
public double getGrade() {
	return grade;
}
public void setGrade(double grade) {
	this.grade = grade;
}
public double getSumgrade() {
	return sumgrade;
}
public void setSumgrade(double sumgrade) {
	this.sumgrade = sumgrade;
}
public double getAverage() {
	return average;
}
public void setAverage(double average) {
	this.average = average;
}
@Override
public String toString() {
	return "Student [id=" + id + ", semester=" + semester + ", teachers_name=" + teachersName + ", nameStudent="
			+ nameStudent + ", surname=" + surname + ", age=" + age + ", weight=" + weight + ", height=" + height
			+ ", fathers_name=" + fathers_name + ", mothers_name=" + mothers_name + ", grade=" + grade + ", sumgrade="
			+ sumgrade + ", average=" + average + "]";
}






	
	
//	public void show() {
//		System.out.println("spring boot created");
//	}
}

