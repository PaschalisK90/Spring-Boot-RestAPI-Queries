package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonIgnore;
@RequestMapping(path="/demo")
@RestController
public class SpringController {
	
	
	@Autowired
	Interface_Subject data;
	@Autowired
	Interface_Student dataStudent;
	@Autowired
	Interface_Semester dataSemester;
	@Autowired
	Interface_Teacher dataTeacher;

//@PostMapping("/student")
//public Student student(Student student) {
//	return data1.save(student);
//	
//}
	@JsonIgnore
@GetMapping("/allstudent")
public Iterable<Student> getStudent(){
	return  dataStudent.findAll();
}
	@JsonIgnore
@GetMapping("/allstudentteacher/{teachersName}")
public List<Student> getStudentByTeacher(@PathVariable("teachersName")String teachersName){
		
	return dataStudent.findByTeachersName(teachersName);
}
	@JsonIgnore
@GetMapping("/allstudent-teacher/{teachersName}")
public List<Object> getStudentBynameOfSubject(@PathVariable("teachersName")String teachersName){
		
	return dataStudent.findByNameOfTeacher(teachersName);
}

 
//  @RequestMapping("student/{id}")
//  @ResponseBody
//public Optional<Student> getStudentId(@PathVariable("id")int id){
//	  System.out.println(dataStudent.findByteachers_name("Takis"));
//	return dataStudent.findById(id);
//}
//@PostMapping("/register_subject")
//public Subject subject(Subject subject) {
//	return data.save(subject);
//	
//}
@JsonIgnore
@GetMapping(path="/Subject/{id}")
public Optional<Subject>getSubject(@PathVariable("id")int id ){
	return data.findById(id);
	
}
@JsonIgnore
@GetMapping("/Subject")
	public Iterable<Subject> getSubject(){
		return  data.findAll();
	}
//@PostMapping("/register_semester")
//public Semester semester(Semester semester) {
//	return data.save(semester);
//	
//}
@JsonIgnore
@GetMapping("/Semester")
public List<Semester> getSemester(){
	return dataSemester.findAll();
}
//@PostMapping("/register_teacher")
//public Teacher teacher(Teacher teacher) {
//	return data.save(teacher);
//	
//}
@JsonIgnore
@GetMapping("/Teacher")
public Iterable<Teacher> getTeacher(){
	return  dataTeacher.findAll();}


}

